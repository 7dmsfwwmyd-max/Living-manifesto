"""UI smoke test for the static app with an in-browser IndexedDB mock.

The container's managed Chromium blocks all navigation. This test injects app
assets into about:blank and mocks IndexedDB transactions. Real on-device
IndexedDB, service workers and iOS installation require device testing.
Run: python tests/test_app.py
"""
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
ROOT=Path(__file__).resolve().parents[1]
HTML=(ROOT/'index.html').read_text()
CSS=(ROOT/'styles.css').read_text()
JS=(ROOT/'app.js').read_text()
IDB_MOCK=r'''
(()=>{
  const stores={records:new Map(),files:new Map()};
  const fake={
    open(){
      const request={};
      setTimeout(()=>{
        const database={
          createObjectStore(){},
          transaction(name){
            const tx={oncomplete:null,onerror:null,onabort:null};
            tx.objectStore=()=>({
              put(v){stores[name].set(v.id,structuredClone(v));setTimeout(()=>tx.oncomplete?.(),5)},
              delete(id){stores[name].delete(id);setTimeout(()=>tx.oncomplete?.(),5)},
              getAll(){const req={};setTimeout(()=>{req.result=Array.from(stores[name].values());req.onsuccess?.()},2);return req},
              get(id){const req={};setTimeout(()=>{req.result=stores[name].get(id)||null;req.onsuccess?.()},2);return req}
            });
            return tx;
          }
        };
        request.result=database;
        request.onupgradeneeded?.();
        setTimeout(()=>request.onsuccess?.(),2);
      },2);
      return request;
    }
  };
  Object.defineProperty(window,"indexedDB",{value:fake,configurable:true});
})();
'''

def page_with_app(browser, mobile=False):
    ctx=browser.new_context(viewport={'width':390 if mobile else 1440,'height':844 if mobile else 900},is_mobile=mobile,has_touch=mobile,device_scale_factor=2 if mobile else 1,accept_downloads=True)
    p=ctx.new_page()
    errors=[]
    p.on('pageerror',lambda e:errors.append(str(e)))
    # Avoid Chromium administrator's URLBlocklist, by running all app assets inline.
    html=__import__("re").sub(r"<meta http-equiv=\"Content-Security-Policy\"[^>]+>","",HTML)
    html=html.replace('<link rel="stylesheet" href="./styles.css">','<style>'+CSS+'</style>')
    html=html.replace('<script src="./app.js" defer></script>','')
    p.goto('about:blank')
    p.set_content(html)
    p.add_script_tag(content=IDB_MOCK)
    p.add_script_tag(content=JS)
    p.wait_for_timeout(700)
    return p,ctx,errors

def main():
    with sync_playwright() as playwright:
        browser=playwright.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
        page,desktop,errors=page_with_app(browser)
        page.get_by_role('button',name='+ Capture a source').click()
        page.locator('#capture-form [name=title]').fill('A careful essay about uncertainty')
        page.locator('#capture-form [name=url]').fill('https://example.org/essay')
        page.locator('#capture-form [name=note]').fill('Preserving options is valuable, but not always.')
        page.locator('#capture-form button[type=submit]').click()
        expect(page.get_by_text('A careful essay about uncertainty')).to_be_visible()
        page.locator('#desktop-nav [data-go="Manifesto"]').click()
        page.get_by_role('button',name='+ Draft principle').click()
        page.locator('#proposal-form textarea').fill('Preserve flexibility when the cost of commitment is high.')
        page.locator('#proposal-form button[type=submit]').click()
        page.get_by_role('button',name='Adopt principle').click()
        expect(page.get_by_text('Preserve flexibility when the cost of commitment is high.')).to_be_visible()
        page.locator('#desktop-nav [data-go="Think"]').click()
        page.locator('#question-form textarea').fill('When should I deliberately commit?')
        page.locator('#question-form button[type=submit]').click()
        expect(page.get_by_text('When should I deliberately commit?')).to_be_visible()
        page.locator('#desktop-nav [data-go="Today"]').click()
        page.screenshot(path=str(ROOT/'tests/desktop.png'),full_page=True)
        page.get_by_role('button',name='Backup & setup').click()
        with page.expect_download() as download_info:page.get_by_role('button',name='Export complete backup').click()
        assert download_info.value.suggested_filename.endswith('.json')
        page.locator('#desktop-nav [data-go="Library"]').click()
        page.locator('#library-search').fill('careful')
        expect(page.get_by_text('A careful essay about uncertainty')).to_be_visible()
        page.locator('#library-search').fill('unmatched query')
        expect(page.get_by_text('No sources match this search.')).to_be_visible()
        page.locator('#library-search').fill('')
        page.get_by_role('button',name='Import iCloud files').click()
        page.locator('#import-form input[type=file]').set_input_files({'name':'capture_test.md','mimeType':'text/markdown','buffer':b'# Captured source\nSource URL(s):\nhttps://example.com/bookmark\n\n## Shared material\nAn intriguing argument about incentives\n\n## My thoughts\nShould investigate whether this generalizes.'})
        page.locator('#import-form button[type=submit]').click()
        expect(page.get_by_text('An intriguing argument about incentives')).to_be_visible()
        assert not errors,errors
        print('Desktop: capture, manifesto approval, thinking desk, export — passed.')
        phone,mobile,errors=page_with_app(browser,True)
        phone.screenshot(path=str(ROOT/'tests/mobile.png'),full_page=True)
        phone.get_by_role('button',name='Capture a source',exact=True).click()
        phone.locator('#capture-form [name=title]').fill('An iPhone thought')
        phone.locator('#capture-form button[type=submit]').click()
        expect(phone.get_by_text('An iPhone thought')).to_be_visible()
        phone.locator('#mobile-nav [data-go="Disciplines"]').click()
        assert phone.get_by_role('heading',name='Disciplines').is_visible()
        assert not errors,errors
        print('Mobile: capture and navigation — passed.')
        browser.close()

if __name__=='__main__': main()
